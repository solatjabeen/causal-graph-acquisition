PySMILE ACADEMIC is the Python wrapper for SMILE 
SMILE: Structural Modeling, Inference and Learning Engine

This software can be used only with a valid license, obtained from BayesFusion, LLC.
The following document contains full terms and conditions of SMILE Academic license:
https://download.bayesfusion.com/license_academic.txt

SMILE Academic can be used without cost for academic teaching and research use.
We would like to stress that "academic teaching and research use" means using the 
software (1) for the purpose of academic teaching or research as part of an 
academic program or an academic research project, and (2) by a user who is 
at the time of use affiliated with an academic institution. In other words, 
affiliation with an academic institution alone, research conducted at government 
or industrial research centers, research conducted by members of university 
faculty in consulting projects, or use in a commercial educational institution 
DO NOT qualify as academic teaching and research use.

The documentation is available at:
http://support.bayesfusion.com/
