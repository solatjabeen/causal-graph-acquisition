# License issued by BayesFusion Licensing Server
#
# This code must be executed before any other rSMILE object is created 
rSMILE::License(paste(
	"SMILE LICENSE e42950f2 b58d6fac e3c14a1e ",
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED ",
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, ",
	"AS DEFINED IN THE BAYESFUSION ACADEMIC ",
	"SOFTWARE LICENSING AGREEMENT. ",
	"Serial #: cpdxi66bo1rzx2upxofz3qbdv ",
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) ",
	"Academic institution: Institute of Business Administration ",
	"Valid until: 2025-04-01 ",
	"Issued by BayesFusion activation server",
	sep=""),as.integer(c(
	-88,-127,91,-109,-92,3,47,-21,-60,-36,89,82,44,33,16,108,
	-77,-98,-70,-33,45,-102,4,96,90,24,121,-59,71,-4,-111,71,
	-68,26,84,98,-57,-56,15,-62,92,42,-37,-58,75,62,-2,-115,
	-64,52,-43,61,-60,-19,88,28,54,-38,-87,55,-97,21,85,53))
)
