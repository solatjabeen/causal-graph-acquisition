REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE e42950f2 b58d6fac e3c14a1e " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: cpdxi66bo1rzx2upxofz3qbdv " +
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2025-04-01 " +
	"Issued by BayesFusion activation server",
	{
	&Ha8,&H81,&H5b,&H93,&Ha4,&H03,&H2f,&Heb,&Hc4,&Hdc,&H59,&H52,&H2c,&H21,&H10,&H6c,
	&Hb3,&H9e,&Hba,&Hdf,&H2d,&H9a,&H04,&H60,&H5a,&H18,&H79,&Hc5,&H47,&Hfc,&H91,&H47,
	&Hbc,&H1a,&H54,&H62,&Hc7,&Hc8,&H0f,&Hc2,&H5c,&H2a,&Hdb,&Hc6,&H4b,&H3e,&Hfe,&H8d,
	&Hc0,&H34,&Hd5,&H3d,&Hc4,&Hed,&H58,&H1c,&H36,&Hda,&Ha9,&H37,&H9f,&H15,&H55,&H35
	})
