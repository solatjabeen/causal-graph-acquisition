// License issued by BayesFusion Licensing Server
// This code must be executed before any other jSMILE object is created
new smile.License(
	"SMILE LICENSE ecfef270 bc4cc695 4af8e89c " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 2t0e11fqti66adbwtenm32onh " +
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2026-02-25 " +
	"Issued by BayesFusion activation server",
	new byte[] {
	-20,72,-55,-19,84,37,53,120,-39,-87,-33,-11,-10,-123,118,-91,
	101,118,-14,113,32,-102,80,-27,22,87,-4,48,-99,-106,-51,40,
	-121,-118,-127,-19,-63,123,114,46,9,-16,-47,86,-37,6,33,-19,
	24,6,-74,-108,-18,-85,-88,-86,45,-96,-73,14,106,17,-65,18
	}
);
