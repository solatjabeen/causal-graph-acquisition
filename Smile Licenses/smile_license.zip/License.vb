REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE ecfef270 bc4cc695 4af8e89c " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 2t0e11fqti66adbwtenm32onh " +
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2026-02-25 " +
	"Issued by BayesFusion activation server",
	{
	&Hec,&H48,&Hc9,&Hed,&H54,&H25,&H35,&H78,&Hd9,&Ha9,&Hdf,&Hf5,&Hf6,&H85,&H76,&Ha5,
	&H65,&H76,&Hf2,&H71,&H20,&H9a,&H50,&He5,&H16,&H57,&Hfc,&H30,&H9d,&H96,&Hcd,&H28,
	&H87,&H8a,&H81,&Hed,&Hc1,&H7b,&H72,&H2e,&H09,&Hf0,&Hd1,&H56,&Hdb,&H06,&H21,&Hed,
	&H18,&H06,&Hb6,&H94,&Hee,&Hab,&Ha8,&Haa,&H2d,&Ha0,&Hb7,&H0e,&H6a,&H11,&Hbf,&H12
	})
