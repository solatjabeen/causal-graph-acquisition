This zip file contains your SMILE licensing key for 
the following programming languages:
  C++    -   smile_license.h
  Python -   pysmile_license.py
  R      -   License.R
  Java   -   License.java
  C#     -   License.cs
  VB.NET -   License.vb
  VBScript - License.vbs  
Each file contains comments at the top; follow the comments 
to integrate the licensing key with your program.
