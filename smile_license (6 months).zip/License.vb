REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE c978699b 97c07af6 f69b7377 " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: damx5dd4ezqly012c37ko4l9i " +
	"Issued for: Solat Jabeen (solatjabeen@gmail.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2024-02-05 " +
	"Issued by BayesFusion activation server",
	{
	&H73,&H67,&H28,&Hba,&H6a,&H03,&H97,&H7f,&H5b,&H89,&H34,&Hc7,&Hc1,&H5a,&H5a,&Hb3,
	&Hec,&H9e,&H9e,&H6a,&H09,&Hd5,&Hc2,&H93,&Hb4,&H57,&H24,&Hc9,&H3d,&Hf8,&H8d,&H25,
	&H96,&Hbd,&H56,&Hb8,&H3c,&Had,&H98,&H00,&Hcb,&H27,&Ha2,&H28,&H4b,&H1f,&H76,&Hb1,
	&H92,&H1a,&H65,&H41,&Hd6,&Hbe,&H12,&Ha3,&H4b,&H60,&H83,&H3f,&H57,&H1d,&Hf7,&H23
	})
