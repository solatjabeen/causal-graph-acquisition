# License issued by BayesFusion Licensing Server
#
# This code must be executed before any other rSMILE object is created 
rSMILE::License(paste(
	"SMILE LICENSE c978699b 97c07af6 f69b7377 ",
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED ",
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, ",
	"AS DEFINED IN THE BAYESFUSION ACADEMIC ",
	"SOFTWARE LICENSING AGREEMENT. ",
	"Serial #: damx5dd4ezqly012c37ko4l9i ",
	"Issued for: Solat Jabeen (solatjabeen@gmail.com) ",
	"Academic institution: Institute of Business Administration ",
	"Valid until: 2024-02-05 ",
	"Issued by BayesFusion activation server",
	sep=""),as.integer(c(
	115,103,40,-70,106,3,-105,127,91,-119,52,-57,-63,90,90,-77,
	-20,-98,-98,106,9,-43,-62,-109,-76,87,36,-55,61,-8,-115,37,
	-106,-67,86,-72,60,-83,-104,0,-53,39,-94,40,75,31,118,-79,
	-110,26,101,65,-42,-66,18,-93,75,96,-125,63,87,29,-9,35))
)
