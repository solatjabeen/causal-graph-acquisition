// License issued by BayesFusion Licensing Server
// This code must be executed before any other jSMILE object is created
new smile.License(
	"SMILE LICENSE b120d7f5 e03fbc6a 3007cd19 " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 5pmgy44gtgzun5gqbh8o40u5n " +
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2024-08-17 " +
	"Issued by BayesFusion activation server",
	new byte[] {
	44,101,110,104,77,121,-15,93,98,-46,-52,-85,47,-115,109,-9,
	64,56,125,-85,-54,-114,-14,106,-128,-75,-18,-35,68,-53,102,29,
	-41,-104,-83,-113,118,-96,28,122,100,-80,-5,-127,98,-81,-42,63,
	-78,6,98,102,-7,95,90,98,116,57,-48,107,-10,3,-17,69
	}
);
