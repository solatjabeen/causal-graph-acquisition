REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE b120d7f5 e03fbc6a 3007cd19 " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 5pmgy44gtgzun5gqbh8o40u5n " +
	"Issued for: Solat Jabeen (solatjabeen@yahoo.com) " +
	"Academic institution: Institute of Business Administration " +
	"Valid until: 2024-08-17 " +
	"Issued by BayesFusion activation server",
	{
	&H2c,&H65,&H6e,&H68,&H4d,&H79,&Hf1,&H5d,&H62,&Hd2,&Hcc,&Hab,&H2f,&H8d,&H6d,&Hf7,
	&H40,&H38,&H7d,&Hab,&Hca,&H8e,&Hf2,&H6a,&H80,&Hb5,&Hee,&Hdd,&H44,&Hcb,&H66,&H1d,
	&Hd7,&H98,&Had,&H8f,&H76,&Ha0,&H1c,&H7a,&H64,&Hb0,&Hfb,&H81,&H62,&Haf,&Hd6,&H3f,
	&Hb2,&H06,&H62,&H66,&Hf9,&H5f,&H5a,&H62,&H74,&H39,&Hd0,&H6b,&Hf6,&H03,&Hef,&H45
	})
